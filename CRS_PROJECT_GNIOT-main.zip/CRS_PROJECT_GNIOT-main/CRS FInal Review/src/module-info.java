/**
 * 
 */
/**
 * 
 */
module GNIOT_CRS_POS_PROJECT {
  requires java.sql;
	
}