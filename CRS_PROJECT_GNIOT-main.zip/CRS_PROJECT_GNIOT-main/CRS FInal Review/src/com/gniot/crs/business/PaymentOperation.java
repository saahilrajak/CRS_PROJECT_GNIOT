package com.gniot.crs.business;

public class PaymentOperation implements PaymentInterface {
public void sendNotification() {
	System.out.println("<---Send Notification--->");
}
}
