/**
 * 
 */
package com.gniot.crs.business;

/**
 * 
 */
public interface PaymentInterface {
	public void sendNotification();


}
