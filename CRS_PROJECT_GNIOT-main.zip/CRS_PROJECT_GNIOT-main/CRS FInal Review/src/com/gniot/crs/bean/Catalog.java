package com.gniot.crs.bean;

public class Catalog {
}
