/**
 * 
 */
package com.gniot.crs.bean;

/**
 * 
 */
public class Admin {
	// Declare all the properties of Customers 
	// more attribute need to be  added
		 private int adminDOJ;		
		
		 public int getAdminDOJ() {
			return adminDOJ;
		}
		public void setAdminDOJ(int adminDOJ) {
			this.adminDOJ = adminDOJ;
		}
		
}
