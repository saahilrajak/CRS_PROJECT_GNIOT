/**
 * 
 */
package com.gniot.crs.constant;

/**
 * 
 */
public class SQLConstant {
public static final String INSERT_COURSES = "INSERT INTO courses (course_id, course_name, course_code) VALUES (?, ?, ?)";
}